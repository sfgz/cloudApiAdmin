<?php
/************************************/
/*                                  */
/*  If a file named                 */
/*                                  */
/*  auth_users.json                 */
/*                                  */
/*  is in the directory             */
/*                                  */
/*  script/Private/Cofig/own        */
/*                                  */
/*  then the that file gets readen  */
/*  and this php - file is obsolete */
/*                                  */  
/*  FIXME the password is admin1    */
/*  TODO change the password        */
/*  in the application itself!      */
/*                                  */
/************************************/

return [
    '0'=> [
        'user' => 'admin',
        'pass' => '$2y$10$BxvMo17tm.9gGhLb60gf9ulF7SyI4qf1/qN/P2btGf5aYPQu6vQKa',
        'group' => '99'
    ],
];

?>
