<?php
/************************************/
/*                                  */
/*  If a file named                 */
/*                                  */
/*  auth_users.json                 */
/*                                  */
/*  is in the directory             */
/*                                  */
/*  script/Private/Cofig/own        */
/*                                  */
/*  then the that file gets readen  */
/*  and this php - file is obsolete */
/*                                  */
/************************************/

return array(
    'someIndex'=> array(
        'user' => 'admin',
        'pass' => 'password like $2y$50$Iheb9CQ7QlhvzAT2u67Yi.TpKX588eXmD7gdS.9kuEEcLyJDa5ShS',
        'group' => '99'
    ),
);

?>
